
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Piloto piloto = new Piloto(" Juan Gabriel ", " Ramiro ", 25, 264573987);
        System.out.println("\nLos datos del piloto son:" + piloto);

        Pasajero pasajero = new Pasajero(" Aaron ", " Ventura ", 19);
        System.out.println("\nLos datos del pasajero es:" + pasajero);

        Pasajero pasajero1 = new Pasajero(" Santiago ", " Ventura ", 24);
        System.out.println("\nLos datos del pasajero es:" + pasajero1);

        Vuelo vuelo = new Vuelo("Peru", 64646946, 2564565,2);

        Reserva reserva = new Reserva("24/10/2024", vuelo, pasajero, 11);
        Reserva reserva1= new Reserva("24/10/2024", vuelo, pasajero1, 11);

        vuelo.agregarReserva(reserva);
        vuelo.agregarReserva(reserva1);

        System.out.println("\nLos datos del vuelo:" + vuelo);
        System.out.println("\nLos datos de la reserva son:" + reserva + "\n" + reserva1);


    }

}