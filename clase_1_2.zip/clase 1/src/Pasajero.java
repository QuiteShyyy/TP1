public class Pasajero extends Persona{
    public Pasajero(String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);

    }
    @Override
    public String toString(){
        return " \nNombre: " + getNombre() + " \nApellido: " + getApellido() + " \nEdad: " + getEdad();
    }

}
