

public class Reserva {
    private String fecha;
    private Vuelo vuelo;
    private int hora;
    private Pasajero pasajero;


    public Reserva(String fecha, Vuelo vuelo, Pasajero pasajero, int hora) {
        this.fecha = fecha;
        this.hora = hora;
        this.pasajero = pasajero;
        this.vuelo = vuelo;


    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }


    @Override
    public String toString() {
        return "\nPasajero: " + pasajero.getNombre() + " " + pasajero.getApellido() +
                "\nEdad: " + pasajero.getEdad() +
                "\nDestino: " + vuelo.getDestino() +
                "\nFecha: " + fecha + "\nHora: " + hora;
    }

}
