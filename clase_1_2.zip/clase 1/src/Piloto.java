public class Piloto extends Persona{
    private int legajo;

    public Piloto(String nombre, String apellido, int edad, int legajo) {
        super(nombre, apellido, edad);
        this.legajo = legajo;
    }

    public int getLegajo() {
        return legajo;
    }

    public void setLegajo(int legajo) {
        this.legajo = legajo;
    }

    @Override
    public String toString() {
        return " \nNombre: " + getNombre() + " \nApellido: " + getApellido() + " \nEdad: " + getEdad() + "\nLegajo: " + getLegajo();

    }
}
