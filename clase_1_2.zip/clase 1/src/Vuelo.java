import java.util.LinkedList;

public class Vuelo {
    private String destino;
    private LinkedList<Reserva> reservas;
    private int patente, numeroVuelo, cantpasajeros;

    public Vuelo(String destino, int patente, int numeroVuelo, int cantpasajeros) {
        this.destino = destino;
        this.reservas = new LinkedList<>();
        this.patente = patente;
        this.numeroVuelo = numeroVuelo;
        this.cantpasajeros=cantpasajeros;
    }

    public int getCantpasajeros() {
        return cantpasajeros;
    }

    public void setCantpasajeros(int cantpasajeros) {
        this.cantpasajeros = cantpasajeros;
    }

    public int getNumeroVuelo() {
        return numeroVuelo;
    }

    public void setNumeroVuelo(int numeroVuelo) {
        this.numeroVuelo = numeroVuelo;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public LinkedList<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(LinkedList<Reserva> reservas) {
        this.reservas = reservas;
    }

    public int getPatente() {
        return patente;
    }

    public void setPatente(int patente) {
        this.patente = patente;
    }

    public void agregarReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    @Override
    public String toString() {

        return " \n Destino: " + getDestino() + "\n Patente: " + getPatente() + "\n Numero de vuelo: " + getNumeroVuelo() + " \n Cantidad de pasajeros: " + getCantpasajeros();
    }
}
